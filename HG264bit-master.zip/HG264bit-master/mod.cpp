dir = "@HG264bit";
author = "Werthles";
hideName = 0;
hidePicture = 0;
description = "https://steamcommunity.com/id/Werthles/myworkshopfiles/?appid=107410";
logo = "\Werthles_HG2Images\iconHG2.paa"; //mod icon when not hovered over and in editor before placing
logoOver = "\Werthles_HG2Images\iconHG2Large.paa"; //mod icon when hovered over
tooltip = "Hired Guns 2 Host Mod (64-bit)"; //word when mod icon hovered over
name = "Hired Guns 2 Host Mod (64-bit)"; // name in expansions
picture = "\Werthles_HG2Images\iconHG2Expansions.paa"; // picture in expansions
overview = "Hired Guns 2 Mod (64-bit)<br/><br/>This is the mod required by hosts of 'Hired Guns 2 (64-bit)'.<br/><br/>Client players do not need to run this as all progress is saved to the host's machine."; //description in expansion menu
actionName = "Feedback"; //instead of purchase in expansions
action = "https://steamcommunity.com/id/Werthles/myworkshopfiles/?appid=107410"; //where WHK Link goes
tooltipOwned = "Hired Guns 2 Host Mod (64-bit)";
overviewPicture = "\Werthles_HG2Images\iconHG2Large.paa";
overviewText = "This is the mod required by hosts of 'Hired Guns 2'.";
overviewFootnote = "Client players do not need to run this as all progress is saved to the host's machine.";